죠스떡볶이: http://jawstopokki.co.kr/index/

첫번째는 bed_index파일
main #one에 position:relative를 없애면 html이 보여지게 되요
* {margin:0; padding:0;} 을 줬는데도 적용이 되지 않아요

두번째는 bed_index파일
main #one #logo_house가 화면을 줄이면 header위로 넘어가는데 안넘어 가게 하고 싶어요